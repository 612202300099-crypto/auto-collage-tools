import { yieldToMain } from './yieldToMain';
import { detectFace } from './aiService';

// ─────────────────────────────────────────────────────────────────
// INTERNAL: build + draw canvas — dipakai oleh kedua export di bawah
// ─────────────────────────────────────────────────────────────────
async function buildCollageCanvas(
  imageFiles: File[],
  customerName: string,
  index: number,
  total: number,
  useAI: boolean = true,
  onPhotoProgress?: (current: number, total: number, status: string) => void
): Promise<HTMLCanvasElement> {
  const PX_PER_CM = 137.795;
  const CANVAS_WIDTH  = Math.round(31 * PX_PER_CM); // 4271 px
  const CANVAS_HEIGHT = Math.round(47 * PX_PER_CM); // 6477 px

  const PHOTO_WIDTH  = Math.round(6 * PX_PER_CM); // 827 px
  const PHOTO_HEIGHT = Math.round(9 * PX_PER_CM); // 1240 px

  const GRID_SIZE = 5;
  const GAP_X = Math.round(0.25 * PX_PER_CM);
  const GAP_Y = Math.round(0.25 * PX_PER_CM);

  const totalGridWidth  = (PHOTO_WIDTH  * GRID_SIZE) + (GAP_X * (GRID_SIZE - 1));
  const totalGridHeight = (PHOTO_HEIGHT * GRID_SIZE) + (GAP_Y * (GRID_SIZE - 1));

  const MARGIN_X = (CANVAS_WIDTH - totalGridWidth) / 2;   // center horizontal
  const MARGIN_Y = CANVAS_HEIGHT - totalGridHeight;        // bottom-aligned (sisa ruang ke atas)

    // Padding yang lebih tipis agar foto terasa lebih "FULL"
  const FRAME_PADDING        = Math.round(PHOTO_WIDTH  * 0.04);  // Perkecil dari 0.08 ke 0.04
  const FRAME_BOTTOM_PADDING = Math.round(PHOTO_HEIGHT * 0.10);  // Perkecil dari 0.15 ke 0.10

  const canvas = document.createElement('canvas');
  canvas.width  = CANVAS_WIDTH;
  canvas.height = CANVAS_HEIGHT;

  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas tidak didukung di browser ini!');

  // Background putih kertas
  ctx.fillStyle = 'rgb(255, 255, 255)';
  ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

  // Helper: load File → HTMLImageElement
  const loadImage = (file: File): Promise<HTMLImageElement> =>
    new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload  = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error(`Gagal memuat ${file.name}`)); };
      img.src = url;
    });

  // Load gambar satu per satu + yield agar tidak memblok decode
  const imgElements: HTMLImageElement[] = [];
  if (imageFiles.length === 0) throw new Error('Tidak ada gambar');

  for (let i = 0; i < imageFiles.length; i++) {
    try {
      const img = await loadImage(imageFiles[i]);
      imgElements.push(img);
      onPhotoProgress?.(i + 1, 25, `Decoding ${imageFiles[i].name}...`);
      await yieldToMain();
    } catch (err) {
      console.error(err); // skip gambar corrupt
    }
  }

  if (imgElements.length === 0) throw new Error('Tidak ada gambar yang valid');

  // Padding hingga 25 slot
  const paddedElements = [...imgElements];
  while (paddedElements.length < 25) {
    paddedElements.push(imgElements[paddedElements.length % imgElements.length]);
  }

  // Cache untuk deteksi wajah agar tidak panggil AI berkali-kali untuk foto yang sama (duplikat)
  const faceCache = new Map<string, any>();

  // Draw 25 polaroid frames — yield setelah setiap foto (kanvas 27MP sangat berat)
  for (let i = 0; i < Math.min(paddedElements.length, 25); i++) {
    const row = Math.floor(i / GRID_SIZE);
    const col = i % GRID_SIZE;
    const left = Math.round(MARGIN_X + (col * (PHOTO_WIDTH  + GAP_X)));
    const top  = Math.round(MARGIN_Y + (row * (PHOTO_HEIGHT + GAP_Y)));

    // 1. Frame latar belakang putih (tanpa border hitam)
    ctx.fillStyle = 'rgb(255, 255, 255)';
    ctx.fillRect(left, top, PHOTO_WIDTH, PHOTO_HEIGHT);

    // 2. Area foto dalam frame
    const img           = paddedElements[i];
    const photoAreaX    = left + FRAME_PADDING;
    const photoAreaY    = top  + FRAME_PADDING;
    const photoAreaW    = PHOTO_WIDTH - FRAME_PADDING * 2;
    const photoAreaH    = PHOTO_HEIGHT - FRAME_PADDING - FRAME_BOTTOM_PADDING;

    // --- ULTRA-SMART ADAPTIVE SCALING (AI) ---
    const currentFile = imageFiles[i % imageFiles.length];
    
    // Default Cover Scale
    let scale = Math.max(photoAreaW / img.naturalWidth, photoAreaH / img.naturalHeight);
    let sw = photoAreaW / scale;
    let sh = photoAreaH / scale;
    let sx = (img.naturalWidth - sw) / 2;
    let sy = (img.naturalHeight - sh) / 2;

    if (useAI) {
      const cacheKey = currentFile.name + currentFile.size;
      let face = faceCache.get(cacheKey);

      if (face === undefined) {
        onPhotoProgress?.(i + 1, 25, `AI Deep Scanning ${currentFile.name}...`);
        face = await detectFace(currentFile);
        faceCache.set(cacheKey, face);
      }

      if (face) {
        // 1. Hitung dimensi wajah dalam pixel
        const fx = (face.xmin / 1000) * img.naturalWidth;
        const fy = (face.ymin / 1000) * img.naturalHeight;
        const fw = ((face.xmax - face.xmin) / 1000) * img.naturalWidth;
        const fh = ((face.ymax - face.ymin) / 1000) * img.naturalHeight;

        // 2. LOGIKA CERDAS: "Kecilin Otomatis" jika wajah tidak muat di crop standar
        // Kita bandingkan: apakah box wajah lebih besar dari jendela potong default (sw/sh)?
        // Jika iya, kita lebarkan jendela potongnya (Zoom Out)
        const requiredScaleW = photoAreaW / fw;
        const requiredScaleH = photoAreaH / fh;
        
        // Pilih scale yang paling "aman" agar semua wajah masuk (Contain-style inside Cover-grid)
        const smartScale = Math.min(requiredScaleW, requiredScaleH, scale);
        
        // Update dimensi potong berdasarkan Smart Scale
        scale = smartScale;
        sw = photoAreaW / scale;
        sh = photoAreaH / scale;

        // 3. Pusatkan pada tengah-tengah grup wajah
        const faceCenterX = fx + fw / 2;
        const faceCenterY = fy + fh / 2;

        sx = faceCenterX - sw / 2;
        sy = faceCenterY - sh / 2;

        // 4. Final Clamp (agar tetap dalam gambar)
        sx = Math.max(0, Math.min(sx, img.naturalWidth - sw));
        sy = Math.max(0, Math.min(sy, img.naturalHeight - sh));
        
        onPhotoProgress?.(i + 1, 25, `AI Smart-Fit applied (Visible faces: 4+)`);
      }
    }
    // ------------------------------------------

    ctx.save();
    ctx.beginPath();
    ctx.rect(photoAreaX, photoAreaY, photoAreaW, photoAreaH);
    ctx.clip();
    ctx.drawImage(img, sx, sy, sw, sh, photoAreaX, photoAreaY, photoAreaW, photoAreaH);
    ctx.restore();

    await yieldToMain(); // yield setelah setiap foto — KRUSIAL anti-freeze
  }

  // --- DRAW CROP MARKS (Garis Potong) ---
  const CROP_MARK_LEN = Math.round(0.35 * PX_PER_CM); // Panjang lengan garis ~4.8mm
  const CROP_LINE_WIDTH = Math.max(2, Math.floor(0.015 * PX_PER_CM));

  const cropX: number[] = [];
  for (let c = 0; c <= GRID_SIZE; c++) {
    if (c === 0) cropX.push(MARGIN_X);
    else if (c === GRID_SIZE) cropX.push(MARGIN_X + totalGridWidth);
    else cropX.push(MARGIN_X + c * PHOTO_WIDTH + (c - 1) * GAP_X + GAP_X / 2);
  }

  const cropY: number[] = [];
  for (let r = 0; r <= GRID_SIZE; r++) {
    if (r === 0) cropY.push(MARGIN_Y);
    else if (r === GRID_SIZE) cropY.push(MARGIN_Y + totalGridHeight);
    else cropY.push(MARGIN_Y + r * PHOTO_HEIGHT + (r - 1) * GAP_Y + GAP_Y / 2);
  }

  ctx.strokeStyle = 'rgb(0, 0, 0)';
  ctx.lineWidth = CROP_LINE_WIDTH;
  
  for (let r = 0; r <= GRID_SIZE; r++) {
    for (let c = 0; c <= GRID_SIZE; c++) {
      const cx = Math.round(cropX[c]);
      const cy = Math.round(cropY[r]);

      ctx.beginPath();
      // Kaki Kiri
      if (c > 0) {
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx - CROP_MARK_LEN, cy);
      }
      // Kaki Kanan
      if (c < GRID_SIZE) {
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + CROP_MARK_LEN, cy);
      }
      // Kaki Atas
      if (r > 0) {
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx, cy - CROP_MARK_LEN);
      }
      // Kaki Bawah
      if (r < GRID_SIZE) {
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx, cy + CROP_MARK_LEN);
      }
      ctx.stroke();
    }
  }

  // Label "NAMA - P1/3" di ruang atas (~1cm)
  const labelWidth  = Math.round(5 * PX_PER_CM);
  const labelHeight = Math.round(MARGIN_Y * 0.6);
  const labelX      = Math.round((CANVAS_WIDTH  - labelWidth)  / 2);
  const labelY      = Math.round((MARGIN_Y - labelHeight) / 2);
  const labelRadius = Math.round(labelHeight * 0.2);

  ctx.fillStyle = 'black';
  ctx.beginPath();
  ctx.roundRect(labelX, labelY, labelWidth, labelHeight, labelRadius);
  ctx.fill();

  const labelText = `${customerName.toUpperCase()} - P${index}/${total}`;
  const fontSize  = Math.round(labelHeight * 0.45);
  ctx.fillStyle    = 'white';
  ctx.font         = `bold ${fontSize}px sans-serif`;
  ctx.textAlign    = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(labelText, labelX + labelWidth / 2, labelY + labelHeight / 2);

  return canvas;
}

// ─────────────────────────────────────────────────────────────────
// EXPORT A: Mode PNG → returns Blob (langsung download per sheet)
// ─────────────────────────────────────────────────────────────────
export async function generateCollageLocal(
  imageFiles: File[],
  customerName: string,
  index: number,
  total: number,
  useAI: boolean = true,
  onPhotoProgress?: (current: number, total: number, status: string) => void
): Promise<Blob> {
  const canvas = await buildCollageCanvas(imageFiles, customerName, index, total, useAI, onPhotoProgress);
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => { if (blob) resolve(blob); else reject(new Error('Gagal membuat PNG blob')); },
      'image/png',
      1.0
    );
  });
}

// ─────────────────────────────────────────────────────────────────
// EXPORT B: Mode PDF → returns JPEG DataURL (untuk embedding ke jsPDF)
//
// KENAPA JPEG bukan PNG:
//   • PNG per sheet → 15-25 MB (lossless, sangat besar)
//   • JPEG q=0.92   → 2-4 MB  (5-10x lebih kecil, kualitas cetak tetap bagus)
//   • Tidak perlu FileReader (Blob→string) → langsung toDataURL, 1 langkah
//   • Ini yang mencegah RAM crash saat mode PDF dengan banyak halaman
// ─────────────────────────────────────────────────────────────────
export async function generateCollageJpegDataURL(
  imageFiles: File[],
  customerName: string,
  index: number,
  total: number,
  useAI: boolean = true,
  onPhotoProgress?: (current: number, total: number, status: string) => void
): Promise<string> {
  // Pastikan kita menunggu buildCollageCanvas selesai sepenuhnya dengan parameter AI yang tepat
  const canvas = await buildCollageCanvas(imageFiles, customerName, index, total, useAI, onPhotoProgress);
  
  // Menggunakan kualitas 0.95 (hampir lossless) agar koordinat Smart-Fit tetap presisi di PDF
  return canvas.toDataURL('image/jpeg', 0.95);
}
